<div align="center">
  <h1>🚀 CommandSpeak</h1>
  <p><b>Terminal Velocity — Natural Language CLI Tools for Developer Workflows</b></p>
  <p><i>A Track 4 Submission for CYHI Hackathon (Team: eteranel byte)</i></p>
</div>

---

**CommandSpeak** is a powerful CLI tool that saves developers time by translating simple English sentences into complex terminal commands. 

No more googling obscure git flags or memorizing exact bash scripts. Just speak plain English, and CommandSpeak executes the right developer commands. Best of all, it works **100% offline** with no external LLM API keys required.

## ✨ Features

- 🧠 **Natural Language Parsing:** Say `"push code to vercel"`, `"deploy my project"`, or `"clean my old branches"`. The built-in keyword scoring engine instantly figures out your intent.
- 📦 **Interactive Repo Manager:** Run `commandspeak repo` to launch a fully interactive TUI (Terminal User Interface). Browse files, edit in Nano/Notepad, commit, push, pull, and branch—without leaving the menu.
- 🖥️ **Real-Time Web Dashboard:** Run `commandspeak ui` to pop open a sleek web UI served over a local Go API server. It automatically tracks every CLI command you execute. 
- 🌐 **Native XAMPP Support:** Host the UI on XAMPP! The included `api.php` acts as a secure bridge, allowing the web frontend to read your CLI database automatically.
- 🛡️ **Git Safety Confirmations:** Before pushing or deploying, it checks your `git status`. If you have uncommitted changes, it warns you before making a mess.
- 🔍 **Dry-Run Mode:** Add `--dry-run` or say `"show me how to deploy"` to see exactly what bash command would run without actually executing it.

---

## 🗺️ How It Works (The Complete Flow)

Here is the exact lifecycle of how a single English sentence becomes a safely executed terminal command and updates your frontend dashboard:

```mermaid
sequenceDiagram
    participant User
    participant CLI as CommandSpeak (Go)
    participant NLP as Local Parser
    participant DB as ~/.commandspeak-activity.json
    participant Shell as Bash/CMD
    participant UI as Web Dashboard

    User->>CLI: types "deploy my project to vercel"
    CLI->>NLP: Sends string to Keyword Engine
    NLP-->>CLI: Returns Intent: DEPLOY
    
    CLI->>Shell: Execute: git add . && git push && vercel --prod
    Shell-->>User: Deployment successful!

    CLI->>DB: Logs exact timestamp, command, and success status
    
    UI->>DB: Auto-polls every 2 seconds via API / api.php
    DB-->>UI: Returns new CLI activity
    UI->>User: Visually displays new command in History with "CLI" badge
```

---

## 🚀 Installation & Setup

You can run CommandSpeak in two ways: either download the pre-packaged ZIP (easiest) or build it from source using Go.

### Method 1: The Easiest Way (Download ZIP)
1. Download the `CommandSpeak-Windows.zip` file directly from this repository.
2. Extract the ZIP file into any folder on your computer.
3. Open a terminal (PowerShell or Command Prompt) in that folder.
4. Run commands directly! (e.g., `.\commandspeak "deploy my project"`)
5. *(Optional)* Add the extracted folder to your system's `PATH` variable so you can run `commandspeak` from anywhere.

### Method 2: Build from Source (Go Extension)
Ensure you have [Go](https://go.dev/) installed on your machine.

```cmd
# 1. Clone the repository
git clone https://github.com/devchavda2007-web/commandspeak.git
cd commandspeak

# 2. Download Go dependencies
go mod tidy

# 3. Build and install the CLI globally
go install
```

> **Note:** Ensure your `~/go/bin` directory (or `%USERPROFILE%\go\bin` on Windows) is in your system's `PATH`.

---

## 📖 Usage Guide

### 1. The Natural Language CLI (All Supported Prompts)
Just type `commandspeak` followed by what you want to do. Here are all the natural language commands (intents) currently supported by the offline parser:

| What you want to do | Example Prompt you can type | Default Command it runs |
|---------------------|-----------------------------|-------------------------|
| **Deploy Project** | `commandspeak "deploy my project to vercel"` | `git add . && git commit -m "update" && git push && vercel --prod` |
| **Push Code** | `commandspeak "push my code with message fixed bug"` | `git add . && git commit -m "fixed bug" && git push` |
| **Check Status** | `commandspeak "show me my git status"` | `git status` |
| **Clone Repo** | `commandspeak "clone repo https://github.com/..."` | `git clone https://github.com/...` |
| **Install Packages**| `commandspeak "install dependencies please"` | `npm install` |
| **Start Server** | `commandspeak "start dev server"` | `npm start` |
| **Run Tests** | `commandspeak "run my tests and build"` | `npm test && npm run build` |
| **Undo Commit** | `commandspeak "undo my last commit"` | `git reset --soft HEAD~1` |
| **Clean Branches** | `commandspeak "clean my old branches"` | `git fetch -p && git branch -vv ...` |
| **Initialize Git** | `commandspeak "initialize git repository"` | `git init` |

> **Pro Tip:** You don't have to type these exactly! The tool uses keyword scoring, so saying `"push it"` or `"send code"` will both trigger the PUSH intent.

### 2. The Interactive Repo Manager (Add GitHub Repos)
You can manage any GitHub repository natively within your terminal without opening a browser or an IDE!

**How to add a repo:**
```cmd
# 1. Pass the URL directly to open the manager menu:
$ commandspeak repo https://github.com/username/project

# 2. Or just type the command and let it prompt you:
$ commandspeak repo
> Enter new GitHub repo URL > [Paste your link here]
```
Once added, it will automatically clone the repository and open a **10-option interactive menu** allowing you to:
1. List files in the repository
2. View a file's contents
3. Edit a file natively (opens in Notepad/Nano)
4. Commit and push your changes
5. Pull latest changes
6. Show git status
7. Show git history (logs)
8. List all branches
9. Switch branches
10. Delete a file

### 3. The Web Dashboard (View History)
Want to see every command you've ever typed or configure your settings in a beautiful GUI?

```cmd
$ commandspeak ui
```
*This instantly opens the local dashboard (`index.html`) in your web browser. No server or PHP required!*

**Inside the Web Dashboard you can:**
- Click the **History** button to view a timeline of all your past commands.
- Filter your history by repository.
- Export your history as a `.sh` script or JSON file.

### 4. Customizing & Personalizing Commands
CommandSpeak is designed to fit *your* specific workflow. You can easily change what bash script executes for any given intent.

**How to customize commands:**
```cmd
$ commandspeak change
```
This opens an interactive terminal wizard. 
1. It will list all currently configured intents (e.g., DEPLOY, PUSH, RUN_TESTS).
2. It asks you which one you want to change.
3. You can type your own custom bash command using placeholders like `{{message}}` or `{{repoUrl}}`.

*(Alternatively, you can open the Web Dashboard using `commandspeak ui` and click the **Personalization** button to edit your templates, configure your default package manager (npm, yarn, pnpm), and change the UI theme!)*

---

## 🔒 Privacy & Architecture

CommandSpeak is designed for **maximum privacy and zero friction**:
1. **Offline NLP**: The natural language parser uses local keyword-scoring heuristics in Go. No code or prompts are sent to OpenAI/Anthropic.
2. **Serverless UI**: The `commandspeak ui` dashboard is a pure static web app that stores your command history directly in your browser's `localStorage`. Zero setup, zero PHP, zero external dependencies required.
3. **No Cloud Syncing**: Your history, configs, and repos never leave your computer. 

## 🏆 CYHI Hackathon Compliance
- **Track 4 (Terminal Velocity)**: Designed specifically to accelerate CLI workflows.
- All development was logged using the `cyhi log` tool.
- Implemented core deliverables: The Go CLI, interactive GitHub manager, NLP parser, and a beautifully visualized local web dashboard.
